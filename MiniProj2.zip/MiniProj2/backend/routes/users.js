const router=require("express").Router();
const User=require("../models/User");

router.post("/register",async (req,res)=>{
    try{
        
        const salt=await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(req.body.password);


    }catch(err){
        res.status(500).json(err)
    }
})

module.exports=router;